#pragma once
#include "OrderBookEntry.h"
#include "CSVReader.h"
#include <string>

using namespace std;

class OrderBook
{

public:
  // construct, reading a csv data file
  OrderBook(string fileName);
  // return vector of all known products in the dataset
  vector<string> getKnownProducts();
  // return vector of Orders according to the sent filters
  vector<OrderBookEntry> getOrders(OrderBookType type, string product, string timestamp);

  /** returns the earliest time in the orderbook */
  string getEarliestTime();

  /** returns the next time after the sent time in the orderbook
   * If there is no next timestamp, wraps around the start
   */
  string getNextTime(string timestamp);

  static double getHighPrice(vector<OrderBookEntry> &orders);
  static double getLowPrice(vector<OrderBookEntry> &orders);

  struct OHLCEntry
  {
    string date;
    double open;
    double high;
    double low;
    double close;
  };

  // return a vector of OHLC entries for a specific product and type, filtered by date
  vector<OHLCEntry> getOHLCData(OrderBookType type, string product, string startDate = "", string endDate = "");

private:
  vector<OrderBookEntry> orders;
};